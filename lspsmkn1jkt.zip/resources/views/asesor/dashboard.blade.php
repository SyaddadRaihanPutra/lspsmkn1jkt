@extends('layouts.asesor.main_layouts')

@section('content')

<h1>{{ $setting->nama_sekolah }}</h1>

@endsection
