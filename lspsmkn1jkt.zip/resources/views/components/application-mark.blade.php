<img src="{{ $setting->logo_sekolah }}" alt="{{ $setting->nama_sekolah }}" width="40">
