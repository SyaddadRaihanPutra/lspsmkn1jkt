<a href="{{ route('dashboard') }}">
    <img src="{{ $setting->logo_sekolah }}" alt="{{ $setting->nama_sekolah }}">
</a>
