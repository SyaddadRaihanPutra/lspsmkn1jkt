<a href="<?php echo e(route('dashboard')); ?>">
    <img src="<?php echo e($setting->logo_sekolah); ?>" alt="<?php echo e($setting->nama_sekolah); ?>">
</a>
<?php /**PATH C:\laragon\www\lspsmkn1jkt\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>