<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1">
                    <li class="breadcrumb-item"><span class="align-middle">
                        <span>
                            <i class="menu-icon tf-icons bx bx-box"></i>
                        </span>
                    </li>
                    <li class="breadcrumb-item active">
                        Data Jurusan
                    </li>
                </ol>
            </nav>

            <!-- Basic Layout -->
            <div class="row">
                <div class="col-xl">
                    <div class="mb-4 card">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                                </button>
                            </div>
                        <?php endif; ?>
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Tambah Data Jurusan</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('master-jurusan.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label class="form-label" for="kelas_id">Kelas</label>
                                    <select name="kelas_id" id="kelas_id" class="form-select" required>
                                        <option value="">---- Pilih Kelas ----</option>
                                        <?php $__currentLoopData = \App\Models\Kelas::pluck('nama_kelas', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas_id => $nama_kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kelas_id); ?>"><?php echo e($nama_kelas); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="basic-default-fullname">Nama Jurusan</label>
                                    <input type="text" class="form-control" name="nama_jurusan"
                                        id="basic-default-fullname" placeholder="Contoh: TKP 1">
                                </div>
                                <button type="submit" class="btn btn-primary">Send</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-xl">
                    <div class="mb-4 card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Data Jurusan</h5>
                        </div>
                        <div class="card-body">
                            <form class="mb-4 d-flex" method="GET" action="/master-jurusan">
                                <input class="form-control me-2" type="search" name="search" placeholder="Search"
                                    aria-label="Search">
                                <button class="btn btn-outline-primary" type="submit">Search</button>
                            </form>
                            <div class="table-responsive text-nowrap">
                                <table class="table table-bordered table-striped">
                                    <thead class="text-center">
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Jurusan</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-center">
                                        <?php if($jurusan->count() > 0): ?>
                                            <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td>
                                                        <?php $__currentLoopData = \App\Models\Kelas::pluck('nama_kelas', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas_id => $nama_kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($j->kelas_id == $kelas_id): ?>
                                                                <?php echo e($nama_kelas); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($j->nama_jurusan); ?>

                                                    </td>
                                                    <td>
                                                        <form class="d-inline" id="delete-form-<?php echo e($j->id); ?>"
                                                            action="<?php echo e(route('master-jurusan.delete', $j->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="button" class="btn btn-danger btn-sm"
                                                                data-toggle="modal"
                                                                data-target="#deleteModal<?php echo e($j->id); ?>">
                                                                <i class="bx bx-trash"></i> Hapus
                                                            </button>

                                                            <!-- Modal -->
                                                            <div class="modal fade" id="deleteModal<?php echo e($j->id); ?>"
                                                                tabindex="-1" role="dialog"
                                                                aria-labelledby="deleteModalLabel<?php echo e($j->id); ?>"
                                                                aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered"
                                                                    style="width: 25rem;">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title"
                                                                                id="deleteModalLabel<?php echo e($j->id); ?>">
                                                                                Konfirmasi Hapus Data</h5>
                                                                            <button type="button" class="btn-close"
                                                                                data-dismiss="modal"
                                                                                aria-label="Close"></button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            Apakah Anda yakin ingin menghapus
                                                                            <?php $__currentLoopData = \App\Models\Kelas::pluck('nama_kelas', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas_id => $nama_kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($j->kelas_id == $kelas_id): ?>
                                                                                    <?php echo e($nama_kelas); ?>

                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php echo e($j->nama_jurusan); ?>?
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary"
                                                                                data-dismiss="modal">Batal</button>
                                                                            <button type="submit" class="text-white btn"
                                                                                style="background-color: #e57373"
                                                                                onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($j->id); ?>').submit();">
                                                                                Hapus
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="3">Data tidak ditemukan</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <div class="mt-4">
                                    <ul class="pagination pagination-sm justify-content-start">
                                        <?php
                                        $paginator = $jurusan->onEachSide(1);
                                        $pages = $paginator->getUrlRange(1, $paginator->lastPage());
                                        ?>
                                        
                                        <?php if($paginator->currentPage() > 1): ?>
                                            <li class="page-item">
                                                <a class="page-link"
                                                    href="<?php echo e($paginator->url($paginator->currentPage() - 1)); ?>">Prev
                                                    Page</a>
                                            </li>
                                        <?php endif; ?>

                                        
                                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="page-item<?php echo e($paginator->currentPage() == $page ? ' active' : ''); ?>">
                                                <a class="border page-link border-primary"
                                                    href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <?php if($paginator->hasMorePages()): ?>
                                            <li class="page-item">
                                                <a class="page-link"
                                                    href="<?php echo e($paginator->url($paginator->currentPage() + 1)); ?>">Next
                                                    Page</a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                    <small>Showing <?php echo e($paginator->firstItem()); ?> to <?php echo e($paginator->lastItem()); ?> of <?php echo e($paginator->total()); ?> entries</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- / Content -->
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
            crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"
            integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous">
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasipresensiv2\resources\views/admin/masterjurusan.blade.php ENDPATH**/ ?>