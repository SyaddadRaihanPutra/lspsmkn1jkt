<?php if($errors->any()): ?>
    <div <?php echo e($attributes); ?>>
        <div class="alert alert-danger d-flex" role="alert">
            <span class="p-3 badge badge-center rounded-pill bg-danger border-label-danger me-2">
                <i class='bx bxs-error fs-6'></i></span>
            <div class="d-flex flex-column ps-1">
                <h6 class="mb-1 alert-heading d-flex align-items-center fw-bold">Error!!</h6>
                <span>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </span>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\aplikasipresensiv2\resources\views/components/validation-errors.blade.php ENDPATH**/ ?>