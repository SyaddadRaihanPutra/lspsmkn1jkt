<style>
    @media (max-width: 767px) {

        .nis,
        .jurusan {
            display: none;
        }
    }

    .bg-color {
        background-color: #e6f9ec;
    }

    .bg-color-trans {
        background-color: rgba(187, 244, 227, 0.28);
    }

    /* Tampilan desktop */
    @media only screen and (min-width: 768px) {
        .kehadiran {
            display: flex;
            justify-content: center;
        }
    }

    /* Tampilan mobile */
    @media only screen and (max-width: 767px) {
        .kehadiran {
            display: block;
            margin: 0 auto;
        }

        .kehadiran .btn {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }
    }
</style>


<?php $__env->startSection('content'); ?>
    <?php
    date_default_timezone_set('Asia/Jakarta');
    $today = date('l'); // Mendapatkan hari saat ini dalam format 'Monday', 'Tuesday', dll.
    $currentTime = date('H:i'); // Mendapatkan waktu saat ini dalam format jam dan menit (24 jam)
    $presensiMessage = ''; // Variabel untuk menyimpan pesan presensi
    $presensiAlertClass = ''; // Variabel untuk menyimpan kelas CSS untuk alert
    $presensiBg = ''; // Variabel untuk menyimpan kelas CSS untuk latar belakang

    switch ($today) {
        case 'Saturday':
        case 'Sunday':
            // Jika hari ini adalah Sabtu atau Minggu (libur)
            $presensiMessage = 'Hari ini sekolah sedang libur.';
            $presensiBg = '#5f61e6'; // Mengatur kelas CSS menjadi 'bg-primary'
            $presensiAlertClass = 'alert-primary'; // Mengatur kelas CSS menjadi 'alert-primary'
            break;
        default:
            // Jika hari ini adalah hari kerja
            if ($currentTime > '10:00') {
                // Jika waktu saat ini telah melewati batas presensi pukul 10.00
                $presensiMessage = 'Telah melewati batas presensi.';
                $presensiAlertClass = 'alert-danger'; // Mengatur kelas CSS menjadi 'alert-danger'
                $presensiBg = '#ff4627'; // Mengatur kelas CSS menjadi 'bg-danger'
            } else {
                // Jika waktu saat ini masih sebelum pukul 10.00
                $presensiMessage = 'Segera melakukan presensi pada hari ini.';
                $presensiMessage .= '<br>Batas Presensi Pukul : 10.00';
                $presensiBg = '#5f61e6'; // Mengatur kelas CSS menjadi 'bg-primary'
                $presensiAlertClass = 'alert-primary'; // Mengatur kelas CSS menjadi 'alert-primary'
            }
            break;
    }
    ?>

    <!-- Menampilkan pesan presensi pada halaman HTML -->
    <div class="mx-4 mt-4 d-block">
        <div class="alert <?= $presensiAlertClass ?> alert-dismissible d-flex" role="alert">
            <span class="p-3 badge badge-center rounded-pill border-label-primary me-2"
                style="background-color: <?= $presensiBg ?>;">
                <i class="bx bx-command fs-6"></i></span>
            <div class="d-flex flex-column ps-1">
                <h6 class="mb-2 alert-heading d-flex align-items-center fw-bold">🔔 Pengingat</h6>
                <small><?php echo $presensiMessage; ?></small>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        </div>
    </div>

    <div class="p-4">
        <div class="card">
            <div class="top-0 card-header sticky-top bg-light d-flex justify-content-between">
                <h5 class="m-0">Data Siswa <?php echo e(str_replace('Ketua ', '', Auth::user()->name)); ?></h5>
                <span class="badge bg-primary rounded-5 d-flex align-items-center">
                    <small>Total Siswa: &nbsp;</small>
                    <small class="m-0 text-center"><?php echo e($studentCount); ?></small>
                </span>
            </div>

            <div class="card-body">
                <div class="mb-4 col-md-4">
                    <form class="d-flex" method="GET" action="/dashboard">
                        <input class="form-control me-2" type="search" name="search" placeholder="Search"
                            aria-label="Search">
                        <button class="btn btn-outline-primary" type="submit">Search</button>
                    </form>
                </div>

                <div class="table-responsive text-nowrap">
                    <table class="table table-bordered">
                        <thead class="table-primary">
                            <tr class="text-center align-middle">
                                <td>
                                    <input type="checkbox" class="form-check-input" id="select-all" name="checkbox"
                                        <?php echo e($currentTime > '10:00' || $currentDay === 'Saturday' || $currentDay === 'Sunday' ? 'disabled' : ''); ?>>
                                </td>
                                <th class="nis">NIS</th>
                                <th>Nama</th>
                                <th class="jurusan">Jurusan</th>
                                <th style="width: 20rem">Actions</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($students->isEmpty()): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Data Tidak Ditemukan</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($students) > 0): ?>
                                        <tr class="text-center">
                                            <td>
                                                <input type="checkbox" class="form-check-input" id="select-all"
                                                    name="checkbox" value="<?php echo e($data->id); ?>"
                                                    <?php echo e($currentTime > '10:00' || $currentDay === 'Saturday' || $currentDay === 'Sunday' ? 'disabled' : ''); ?>>

                                            </td>
                                            <td class="nis">
                                                <strong><?php echo e($data->nis); ?></strong>
                                            </td>
                                            <td><?php echo e($data->name); ?></td>
                                            <td class="jurusan">
                                                <?php $__currentLoopData = \App\Models\Kelas::pluck('nama_kelas', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas_id => $nama_kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($data->kelas_id == $kelas_id): ?>
                                                        <?php echo e($nama_kelas); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = \App\Models\Jurusan::pluck('nama_jurusan', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan_id => $nama_jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($data->jurusan_id == $jurusan_id): ?>
                                                        <?php echo e($nama_jurusan); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <?php if($currentTime > '10:00'): ?>
                                                    <p>
                                                        Melewati Batas Waktu Presensi
                                                    </p>
                                                <?php else: ?>
                                                    <div class="gap-2 d-flex justify-content-center">
                                                        <div class="gap-2 kehadiran">
                                                            <button type="button"
                                                                class="btn btn-primary btn-sm">HADIR</button>
                                                            <button type="button"
                                                                class="btn btn-warning btn-sm">IZIN</button>
                                                            <button type="button"
                                                                class="btn btn-danger btn-sm">ALPHA</button>
                                                            <button type="button" class="btn btn-dark btn-sm">PKL</button>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td></td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center">Tidak ada data</td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if($students->isEmpty()): ?>
                <?php else: ?>
                    <?php if($currentTime > '10:00' || $currentDay === 'Saturday' || $currentDay === 'Sunday'): ?>
                    <div class="d-flex justify-content-center align-items-center">
                        <div class="text-center" style="cursor: not-allowed;">
                          <button class="m-auto mt-3 btn btn-success" disabled>Kirim Absen</button>
                        </div>
                      </div>

                    <?php else: ?>
                        <button class="m-auto mt-3 btn btn-success d-block">Kirim Absen</button>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script>
        // Add event listener to the "Select All" checkbox
        document.getElementById("select-all").addEventListener("change", function() {
            var checkboxes = document.getElementsByClassName("form-check-input");
            var numSelected = 0;
            for (var i = 0; i < checkboxes.length; i++) {
                checkboxes[i].checked = this.checked;
                if (this.checked) {
                    checkboxes[i].closest("tr").classList.add("bg-color-trans");
                    numSelected++;
                } else {
                    checkboxes[i].closest("tr").classList.remove("bg-color-trans");
                }
            }
            document.getElementById("num-selected").innerHTML = numSelected;
        });

        // Add event listener to each checkbox
        var checkboxes = document.getElementsByClassName("form-check-input");
        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].addEventListener("change", function() {
                var numSelected = 0;
                for (var i = 0; i < checkboxes.length; i++) {
                    if (checkboxes[i].checked) {
                        checkboxes[i].closest("tr").classList.add("bg-color-trans");
                        numSelected++;
                    } else {
                        checkboxes[i].closest("tr").classList.remove("bg-color-trans");
                    }
                }
                document.getElementById("num-selected").innerHTML = numSelected;
                if (numSelected == checkboxes.length) {
                    document.getElementById("select-all").checked = true;
                } else {
                    document.getElementById("select-all").checked = false;
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ketuakelas.main_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasipresensiv2\resources\views/ketuakelas/dashboard.blade.php ENDPATH**/ ?>