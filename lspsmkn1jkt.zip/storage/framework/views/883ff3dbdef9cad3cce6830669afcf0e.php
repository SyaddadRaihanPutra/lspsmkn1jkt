<?php $__env->startSection('content'); ?>

<h1><?php echo e($setting->nama_sekolah); ?></h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.asesi.main_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lspsmkn1jkt\resources\views/asesi/dashboard.blade.php ENDPATH**/ ?>