<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(('assets/bootstrap/css/bootstrap.min.css')); ?>">
    <title>Registrasi Asesi | LSP SMKN 1 JAKARTA</title>
     <!-- Favicon -->
     <link rel="icon" type="image/x-icon" href=" assets/img/favicon/LSP-SMKN1.ico" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap');

        body {
            font-family: 'Poppins', sans-serif;
            background: #ececec;
        }

        .box-area {
            width: 930px;
        }

        .right-box {
            padding: 40px 30px 40px 40px;
        }

        ::placeholder {
            font-size: 16px;
        }

        .rounded-4 {
            border-radius: 20px;
        }

        .rounded-5 {
            border-radius: 30px;
        }

        @media only screen and (max-width: 768px) {

            .box-area {
                margin: 0 10px;

            }

            .left-box {
                height: 100px;
                overflow: hidden;
            }

            .right-box {
                padding: 20px;
            }
        }
    </style>
</head>

<body>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="p-3 bg-white border shadow row rounded-5 box-area">
            <div class="col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box"
                style="background: #103cbe;">
                <div class="mb-3 featured-image">
                    <img src="assets/img/1.png" class="img-fluid" style="width: 250px;">
                </div>
                
                <small class="text-center text-white text-wrap"
                    style="width: 17rem;">Data yang anda berikan akan menjadi acuan saat memverifikasi data</small>
            </div>
            <div class="col-md-6 right-box">
                <div class="row align-items-center">
                    <div class="mb-4 header-text">
                        <h2>Registrasi Peserta Asesi</h2>
                        <p>Isi data diri anda dengan benar</p>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-item"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('register-post')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="mb-3 input-group">
                            <input type="text" name="name" class="form-control form-control-lg bg-light fs-6"
                                placeholder="Nama Lengkap">
                        </div>
                        <div class="mb-3 input-group">
                            <input type="text" name="email" class="form-control form-control-lg bg-light fs-6"
                                placeholder="Alamat Email">
                        </div>
                        <div class="mb-3 input-group">
                            <input type="password" name="password" class="form-control form-control-lg bg-light fs-6"
                                placeholder="Kata Sandi">
                        </div>
                        <div class="mb-3 input-group">
                            <select name="sekolah_id" id="sekolah_id" class="form-select">
                                <option value="" selected disabled>----- Pilih Sekolah -----</option>
                                <?php $__currentLoopData = $sekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id_sekolah); ?>"><?php echo e($item->nama_sekolah); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3 input-group">
                            <select name="jurusan_id" id="jurusan_id" class="form-select">
                                <option value="" selected disabled>----- Pilih Jurusan -----</option>
                                <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($j->id); ?>"><?php echo e($j->nama_jurusan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3 input-group">
                            <button class="btn btn-lg btn-primary w-100 fs-6">Register</button>
                        </div>
                    </form>
                    <div class="row">
                    <small>Sudah punya akun? <a href="<?php echo e(route('login')); ?>" class="text-decoration-none">Masuk</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<?php /**PATH C:\laragon\www\lspsmkn1jkt\resources\views/auth/register.blade.php ENDPATH**/ ?>