<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\MasterController;
use App\Http\Controllers\RegisController;
use App\Http\Controllers\SettingController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return redirect('/login');
});

Route::get('/logout', function () {
    return redirect('/dashboard');
});


// TEST KONEKSI DATABASE

// Route::get('koneksi', function () {
//     try {
//         DB::connection()->getPdo();
//         echo "Connected successfully to: " . DB::connection()->getDatabaseName();
//     } catch (\Exception $e) {
//         die("Could not connect to the database. Please check your configuration. error:" . $e);
//     }
// });

Route::get('/register-asesi', [RegisController::class, 'index'])->name('register');
Route::post('/register-asesi', [RegisController::class, 'register'])->name('register-post');

Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('settings', [SettingController::class, 'setting'])->name('settings');
    Route::patch('settings', [SettingController::class, 'update_setting'])->name('setting.update');

    Route::get('master-jurusan', [MasterController::class, 'master_jurusan'])->name('master-jurusan');
    Route::get('master-jurusan/{id}', [MasterController::class, 'jurusan_show'])->name('master-jurusan.show');
    Route::get('master-jurusan/create', [MasterController::class, 'master_jurusan_create'])->name('master-jurusan.create');
    Route::post('master-jurusan/store', [MasterController::class, 'master_jurusan_store'])->name('master-jurusan.store');
    Route::delete('master-jurusan/delete/{id}', [MasterController::class, 'jurusan_destroy'])->name('master-jurusan.delete');


    Route::get('master-asesor', [MasterController::class, 'master_asesor'])->name('master-asesor');
    Route::get('master-asesor/create', [MasterController::class, 'master_asesor_create']);
    Route::post('master-asesor/store', [MasterController::class, 'master_asesor_store'])->name('master-asesor-store');
    Route::get('master-asesor/{id}/edit', [MasterController::class, 'master_asesor_edit'])->name('master-asesor-edit');
    Route::put('master-asesor/{id}', [MasterController::class, 'master_asesor_update'])->name('master-asesor-update');
    Route::delete('master-asesor/delete/{id}', [MasterController::class, 'master_asesor_destroy'])->name('master-asesor-delete');

    Route::get('master-wk', [MasterController::class, 'master_wk'])->name('master-wk');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->get(
    '/dashboard',
    [DashboardController::class, 'index']
)->name('dashboard');

// Route::get('logout', function () {
//     Auth::logout();
//     return redirect('/login');
// });
