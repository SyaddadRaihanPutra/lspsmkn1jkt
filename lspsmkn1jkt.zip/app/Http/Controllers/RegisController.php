<?php

namespace App\Http\Controllers;

use App\Models\Jurusan;
use App\Models\Sekolah;
use App\Models\User;
use Illuminate\Http\Request;

class RegisController extends Controller
{
    /**
     * Menampilkan formulir pendaftaran siswa.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $sekolah = Sekolah::all();
        $jurusan = Jurusan::all();
        return view('auth.register', compact('sekolah', 'jurusan'));
    }

    /**
     * Menangani proses pendaftaran siswa.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
        // Validasi data yang diterima dari formulir
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'password' => 'required|string|min:8',
            'sekolah_id' => 'required',
            'jurusan_id' => 'required',
        ]);

        // dd($request->all());

        // Membuat instance siswa dan menyimpan data ke dalam database
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'sekolah_id' => $request->sekolah_id,
            'jurusan_id' => $request->jurusan_id,
        ]);

        // Mengembalikan respons redirect dan menampilkan pesan sukses
        return redirect()->route('login')->with('success', 'Pendaftaran berhasil! Silahkan login untuk melanjutkan.');
    }
}
